# CarbonCoinConfig: ETH → USDC Conversion & Production Optimization

## Configuration Comparison

### Fee Configuration

| Parameter | Old (ETH) | New (USDC) | Rationale |
|-----------|-----------|------------|-----------|
| **buyFee** | 30 (0.3%) | 100 (1%) | Increased for protocol sustainability since gas is sponsored |
| **sellFee** | 30 (0.3%) | 100 (1%) | Increased for protocol sustainability |
| **maxFee** | 300 (3%) | 500 (5%) | Higher ceiling for governance flexibility |

**Reasoning:**
- **0.3% was too low** for a creator token platform. Standard DEXs charge 0.25-0.3%, but you're providing additional value (gasless, curation, etc.)
- **1% is competitive** and sustainable for platform operations
- **Sponsored gas** means users save money elsewhere, so slightly higher fees are acceptable
- **5% max** allows governance to adjust if needed without redeployment

---

### Anti-Bot Configuration

| Parameter | Old (ETH) | New (USDC) | Conversion Logic |
|-----------|-----------|------------|------------------|
| **antiBotDuration** | 60s | 120s | Extended for better protection |
| **maxBuyAmountEarly** | 1 ETH | 100 USDC | 1 ETH ≈ $200 @ $200/ETH → 100 USDC (conservative) |
| **maxWalletPercentage** | 300 (3%) | 200 (2%) | Tightened for fairer distribution |
| **cooldownPeriod** | 10s | 15s | Slightly increased to prevent spam |
| **minBuyAmount** | 0.001 ETH | 1 USDC | 0.001 ETH ≈ $0.20 → 1 USDC (anti-dust) |

**Reasoning:**

#### antiBotDuration: 60s → 120s (2 minutes)
- **Why increase?** First 2 minutes are critical for fair launch
- Bots are sophisticated; 60s is too short
- 2 minutes gives real users time to participate
- Can be adjusted via governance post-launch

#### maxBuyAmountEarly: 1 ETH → 100 USDC
**Original thinking:** 1 ETH ≈ $200 (at historical prices)
**USDC equivalent:** Should be similar dollar value
**Decision:** 100 USDC is conservative and prevents whales from dominating launch
- If token starts at $0.00033, 100 USDC buys ~303,030 tokens
- That's 3.03% of the 10M supply (reasonable for early buyer)
- Prevents single user from buying >10% at launch

#### maxWalletPercentage: 3% → 2%
- **3% was generous** for a creator token
- **2% is standard** for fair-launch tokens
- With 10M supply, 2% = 200,000 tokens max per wallet
- Prevents concentration, encourages distribution

#### cooldownPeriod: 10s → 15s
- 10s allows 6 buys per minute (360 per hour from single address)
- 15s allows 4 buys per minute (240 per hour)
- Negligible for humans, effective against bots
- Still fast enough for legitimate trading

#### minBuyAmount: 0.001 ETH → 1 USDC
- Prevents dust attack spam
- 1 USDC is ~$1, reasonable minimum
- At starting price ($0.00033), 1 USDC = ~3,030 tokens
- Meaningful purchase, not just noise

---

### Circuit Breaker Configuration

| Parameter | Old (ETH) | New (USDC) | Rationale |
|-----------|-----------|------------|-----------|
| **maxPriceImpact** | 1000 (10%) | 500 (5%) | Tighter protection against manipulation |
| **volatilityWindow** | 5 min | 5 min | Unchanged - good window size |
| **maxVolatilityMoves** | 5 | 3 | More conservative - triggers earlier |
| **circuitBreakerDuration** | 10 min | 15 min | Longer cooldown for stability |

**Reasoning:**

#### maxPriceImpact: 10% → 5%
- **10% is huge** for a single transaction in a bonding curve
- **5% is aggressive** but still allows large buys
- At $10k graduation with 5M tokens sold, a 5% impact trade is ~$500 USDC
- Prevents manipulation while allowing legitimate large purchases
- Whitelisted addresses (platform, partners) bypass this anyway

#### maxVolatilityMoves: 5 → 3
- **5 large moves in 5 minutes** suggests manipulation or panic
- **3 moves** triggers circuit breaker earlier, protecting users
- Still allows natural volatility from normal trading
- Prevents pump-and-dump schemes

#### circuitBreakerDuration: 10 min → 15 min
- When circuit breaker triggers, something is wrong
- 10 min might not be enough for users to assess situation
- 15 min gives time for:
  - Community to discuss what's happening
  - Platform to investigate potential exploit
  - Market to stabilize
- Can manually reset if false positive

---

### Whale Limit Configuration

| Parameter | Old (ETH) | New (USDC) | Conversion Logic |
|-----------|-----------|------------|------------------|
| **whaleThreshold** | 10 ETH | 1,000 USDC | 10 ETH @ $200 = $2,000 → 1,000 USDC (conservative) |
| **whaleDelay** | 2 min | 5 min | Increased for better protection |
| **maxTradeSize** | 30 ETH | 2,500 USDC | 30 ETH @ $200 = $6,000 → 2,500 USDC (conservative) |
| **maxSellPercentage** | 300 (3%) | 200 (2%) | Tightened to prevent dumps |

**Reasoning:**

#### whaleThreshold: 10 ETH → 1,000 USDC
**Original:** 10 ETH @ $200/ETH = $2,000
**New:** 1,000 USDC

**Why lower?**
- Original calculation assumed $200/ETH (outdated)
- $1,000 is a significant trade for a micro-cap creator token
- At graduation ($10k total), $1,000 is 10% of liquidity
- This should trigger whale protections
- Whitelisted users bypass anyway

**Who gets flagged as whale?**
- Someone buying $1,000+ of a token with $10k total liquidity
- This is a whale in this context
- Forces them to use intent system (5 min delay)

#### whaleDelay: 2 min → 5 min
- **2 minutes is short** for a whale intent system
- **5 minutes** allows:
  - Community to see large trade coming
  - Price discovery from smaller trades
  - Prevents flash attacks
- Still reasonable for legitimate large buyers
- Can emergency whitelist VCs/partners if needed

#### maxTradeSize: 30 ETH → 2,500 USDC
**Original:** 30 ETH @ $200/ETH = $6,000
**New:** 2,500 USDC

**Why lower?**
- $6,000 would be 60% of graduation liquidity ($10k)
- That's way too high
- $2,500 is 25% of graduation liquidity (still large!)
- Forces mega-whales to split into multiple trades
- Prevents single transaction from crashing price

**Example at graduation:**
- Liquidity: $10,000 USDC + tokens
- Max trade: $2,500 USDC (25% of liquidity)
- Still a huge trade relative to size
- Prevents 50%+ liquidity dumps

#### maxSellPercentage: 3% → 2%
- **3% of 10M** = 300,000 tokens per sell
- **2% of 10M** = 200,000 tokens per sell

At graduation (~5M sold):
- 2% = 100,000 tokens
- If graduation price is $0.012, that's $1,200 sell
- Reasonable for taking profits
- Prevents massive dumps that crash price

---

## Creator Reserve

| Parameter | Old | New | Notes |
|-----------|-----|-----|-------|
| **creatorReservePct** | N/A | 1000 (10%) | Now configurable |
| **Min** | N/A | 500 (5%) | Governance floor |
| **Max** | N/A | 2000 (20%) | Governance ceiling |

**Why make this configurable?**
- Different artists may want different reserves
- 10% is good default (aligns with your spec)
- Governance can adjust per-token if needed
- Bounds prevent abuse (5-20% range)

---

## Decimal Conversions Summary

### ETH (18 decimals) → USDC (6 decimals)

```javascript
// OLD (ETH)
1 ether = 1 * 10**18 = 1,000,000,000,000,000,000

// NEW (USDC)
1 USDC = 1 * 10**6 = 1,000,000
```

### Conversion Examples

| Description | ETH Value | ETH (wei) | USDC Value | USDC (raw) |
|-------------|-----------|-----------|------------|------------|
| Min buy | 0.001 ETH | 1,000,000,000,000,000 | 1 USDC | 1,000,000 |
| Early max | 1 ETH | 1,000,000,000,000,000,000 | 100 USDC | 100,000,000 |
| Whale | 10 ETH | 10,000,000,000,000,000,000 | 1,000 USDC | 1,000,000,000 |
| Max trade | 30 ETH | 30,000,000,000,000,000,000 | 2,500 USDC | 2,500,000,000 |

---

## Production Deployment Recommendations

### Phase 1: Conservative Launch (Recommended)
Use the values in the new config:
- **Fees**: 1% buy/sell
- **Anti-bot**: Strict (2 min duration, 100 USDC max early)
- **Whale limits**: Conservative (1,000 USDC threshold)

**Why?** Better to launch conservative and relax later than launch loose and have issues.

### Phase 2: Post-Launch Adjustment (Week 1-2)
Based on data, potentially:
- Reduce `antiBotDuration` to 60s if no bot issues
- Increase `maxBuyAmountEarly` to 200 USDC if limiting legitimate users
- Adjust `whaleThreshold` based on average trade sizes

### Phase 3: Maturity (Month 1+)
- Lower fees to 0.5% if volume is high
- Relax whale limits if market is healthy
- Adjust based on community governance

---

## Security Considerations

### What These Limits Prevent

1. **Sandwich Attacks**: Circuit breaker + price impact limits
2. **Pump & Dump**: Whale delays + volatility monitoring
3. **Bot Sniping**: Anti-bot duration + cooldowns
4. **Flash Loans**: Min buy amount + cooldowns
5. **Single Whale Dominance**: Max wallet + max sell percentage
6. **Manipulation**: All of the above combined

### What They Allow

1. **Legitimate Large Buyers**: Via whitelist or whale intent system
2. **Normal Trading**: All limits are reasonable for retail
3. **Price Discovery**: Circuit breakers allow natural volatility
4. **Fair Launch**: Anti-bot protections give everyone a chance

---

## Testing Scenarios

### Scenario 1: Fair Launch
```
T+0s: Token launches
T+0-120s: Anti-bot active
  - Max buy: 100 USDC
  - Cooldown: 15s
  - Max wallet: 2% (200k tokens)
  
Result: 
- First 2 minutes, max 8 buys per user (120s / 15s)
- Max spend: 800 USDC per user in first 2 min
- At $0.00033 start price, 800 USDC = ~2.4M tokens (24% of supply)
  - BUT max wallet is 2%, so capped at 200k tokens
- Multiple users needed to distribute supply fairly ✓
```

### Scenario 2: Whale Buy
```
Whale wants to buy 1,500 USDC worth (>1,000 threshold):

Step 1: Whale submits intent (on-chain or via platform)
Step 2: 5 minute delay starts
Step 3: Community sees intent, can prepare
Step 4: After 5 min, whale executes buy
Step 5: Next whale trade requires another 5 min delay

Protection:
- No surprise dumps
- Community awareness
- Time for price discovery
```

### Scenario 3: Manipulation Attempt
```
Attacker tries to manipulate price:

Buy 1: +4% price impact ✓ (under 5% limit)
Buy 2: +4% price impact ✓ 
Buy 3: +4% price impact ✓
- Circuit breaker triggered! (3 moves in 5 min)
- Trading paused for 15 minutes
- Attacker cannot continue pump
- Community has time to assess
```

---

## Governance Functions

All parameters can be updated via `onlyOwner`:

```solidity
// Update fees
config.updateDefaultFeeConfig(FeeConfig({
  buyFee: 50,   // 0.5%
  sellFee: 50,  // 0.5%
  maxFee: 500   // 5%
}));

// Update anti-bot
config.updateDefaultAntiBotConfig(AntiBotConfig({
  antiBotDuration: 180,          // 3 minutes
  maxBuyAmountEarly: 200 * 10**6, // 200 USDC
  maxWalletPercentage: 300,       // 3%
  cooldownPeriod: 10,             // 10s
  minBuyAmount: 5 * 10**5         // 0.5 USDC
}));

// Update whale limits
config.updateDefaultWhaleLimitConfig(WhaleLimitConfig({
  whaleThreshold: 2000 * 10**6,   // 2,000 USDC
  whaleDelay: 3 minutes,          // 3 min
  maxTradeSize: 5000 * 10**6,     // 5,000 USDC
  maxSellPercentage: 300          // 3%
}));

// Update creator reserve (for new tokens)
config.updateCreatorReservePct(1500); // 15%
```

---

## Quick Reference: Config Values

### For Deployment

```javascript
// In your deployment script:
const config = {
  fees: {
    buy: 1,          // 1%
    sell: 1,         // 1%
    max: 5           // 5%
  },
  antiBot: {
    duration: 120,        // 2 minutes
    earlyMax: 100,        // 100 USDC
    maxWallet: 2,         // 2%
    cooldown: 15,         // 15 seconds
    minBuy: 1            // 1 USDC
  },
  circuitBreaker: {
    priceImpact: 5,      // 5%
    window: 5,           // 5 minutes
    moves: 3,            // 3 moves
    duration: 15         // 15 minutes
  },
  whaleLimits: {
    threshold: 1000,     // 1,000 USDC
    delay: 5,           // 5 minutes
    maxTrade: 2500,     // 2,500 USDC
    maxSell: 2          // 2%
  },
  creatorReserve: 10    // 10%
};
```

---

## Summary of Changes

| Category | Key Changes | Impact |
|----------|-------------|--------|
| **Fees** | 0.3% → 1% | More sustainable, still competitive |
| **Anti-Bot** | Stricter limits, USDC amounts | Better launch protection |
| **Circuit Breaker** | 10% → 5% impact, 5 → 3 moves | Earlier protection triggers |
| **Whale Limits** | Lower thresholds, longer delays | Better distribution |
| **Decimals** | 18 → 6 for all USDC amounts | Proper USDC compatibility |
| **Governance** | All adjustable post-launch | Flexibility for optimization |

These values strike a balance between:
- ✅ **Protection**: Preventing manipulation and unfair launches
- ✅ **Usability**: Not overly restrictive for legitimate users  
- ✅ **Sustainability**: Fees support platform operations
- ✅ **Flexibility**: Can adjust via governance based on data

Ready for production deployment! 🚀
